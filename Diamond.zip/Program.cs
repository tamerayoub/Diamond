﻿using System;

namespace Diamond_6._23_6._24_
{
    class Program
    {
        static void Main(string[] args)
        {
            //------------------------NO TOUCHY BELOW THE LINEY IT WORKEY WORKEY
            int numRow;
            string symbol;

            int completedRow = 0;
            
            Console.WriteLine("Type in one of the four symbols to create your diamond with. The options are * or $ or # or @");
            symbol = Console.ReadLine();
            while (!(symbol == "*" || symbol == "$" || symbol == "#" || symbol == "@"))
            {
                Console.WriteLine("Please enter one of the listed symbols.");
                symbol = Console.ReadLine();
            }
            Console.WriteLine("Choose a number to decice how much rows your diamond will get. The number must be an odd number through the range 1 - 19");
            numRow = int.Parse(Console.ReadLine());
            while (numRow > 19 || numRow < 1 || numRow % 2 == 0)
            {
                Console.WriteLine("Please enter an odd number.");
                numRow = int.Parse(Console.ReadLine());
            }

            int symbols = 1;
            
            for (int i = 1; i <= (numRow/2)+1; i++)
            {
                for (int j = ((numRow - symbols)/2); j > 0; j--)
                {
                    Console.Write(" ");
                    
                }
                for (int k = 1; k <=symbols; k++)
                {
                    Console.Write($"{symbol}");
                }

                for (int z = ((numRow - symbols) / 2); z > 0; z--)
                {
                    Console.Write(" ");

                }

                Console.WriteLine();

                symbols+=2;
                completedRow++;
            }
            //------------------------NO TOUCHY ABOVE THE LINEY IT WORKEY WORKEY

            symbols = numRow - 2;
            for (int i = numRow-completedRow; i >= 1; i--)
            {
                
                for (int j = ((numRow - symbols) / 2); j > 0; j--)
                {
                    Console.Write(" ");

                }
                for (int k = 1; k <= symbols; k++)
                {
                    Console.Write($"{symbol}");
                }

                for (int z = ((numRow - symbols) / 2); z > 0; z--)
                {
                    Console.Write(" ");

                }

                Console.WriteLine();

                symbols -= 2;

            }
























        }
    }
}
